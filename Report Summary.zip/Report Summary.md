﻿## ![](Aspose.Words.90f48d98-ab78-4230-b02f-72554bfa8407.001.jpeg)
## ![](Aspose.Words.90f48d98-ab78-4230-b02f-72554bfa8407.002.jpeg)**Techstack Used**
**Data** - HR Data with over 22000 rows from the year 2000 to 2020.

**Data Cleaning & Analysis** - MySQL, Jupyter Notebook(sql workbench)

**Data Visualization** - PowerBI

**Questions**

1. What is the gender breakdown of employees in the company?
1. What is the race/ethnicity breakdown of employees in the company?
1. How many employees work at headquarters versus remote locations?
1. How does the gender distribution vary across departments and job titles?
1. What is the distribution of job titles across the company?
1. What is the distribution of employees across locations by state?

**Summary of Findings**

- There are more male employees
- White race is the most dominant while Native Hawaiian and American Indian are the least dominant.
- A large number of employees work at the headquarters versus remotely.
- The gender distribution across departments is fairly balanced but there are generally more male than female employees.
- A large number of employees come from the state of Ohio.
- Most of the men and women are in engineering department.

